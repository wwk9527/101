# 计算概论(B) 课前问题1

Updated 1752 GMT+8 Aug 23, 2024



2024 fall, Complied by Hongfei Yan

Markdown（用 https://typoraio.cn 编辑）格式文件在，https://github.com/GMyhf/2024spring-cs201



| 课程号和名: 04831410，计算概论(B)                            | 班号: 11                                                    |
| ------------------------------------------------------------ | ----------------------------------------------------------- |
| 上课时间: 1-16周 每周 周二 7-9节                             | 地点: 二教107                                               |
| 上机时间: 1-15周 每周 周四 7-8节<br/>期末机考时间: 2025.12.26 周四 7-8节<br/>期末笔试时间: 2025年1月7日下午 | 地点：7号机房（理科1号楼三层1339房间）和8号机房（1338房间） |
| 助教：熊江凯、罗熙佑、涂程颖、王嘉林                         | 在课程微信群中的名字是“TA-”开始，地点：理科1号楼1220        |



在学习编程的过程中，需要敲击键盘输入代码，尤其是机考时候，当然是又快又准的敲出代码会有优势。2019年秋季我敲了一些《新概念英语》第3册和第4册的文章，并记录了时间，以此来练习盲打。
请同学练习盲打，接近我的完成时间为止。**如果方便请给出你的盲打记录，至少1篇，在课程微信群中展示**。



## 1. Fingers in position, hands ready

https://www.readandspell.com/us/finger-placement-for-typing

<img src="https://raw.githubusercontent.com/GMyhf/img/main/img/image-20230903111445819.png" alt="image-20230903111445819" style="zoom:50%;" />

<center>图1 盲打指法</center>

## 2. 盲打记录



<img src="https://raw.githubusercontent.com/GMyhf/img/main/img/image-20230903111622511.png" alt="image-20230903111622511" style="zoom:50%;" />


<center>图2 盲打《新概念英语》第3册第27篇文章的时间花费6分54秒</center>



<img src="https://raw.githubusercontent.com/GMyhf/img/main/img/image-20230903111916835.png" alt="image-20230903111916835" style="zoom:50%;" />

<center>图3 盲打《新概念英语》第3册部分文章时间花费</center>



<img src="https://raw.githubusercontent.com/GMyhf/img/main/img/image-20230903112208678.png" alt="image-20230903112208678" style="zoom:50%;" />

<center>图4 盲打《新概念英语》第4册部分文章时间花费</center>